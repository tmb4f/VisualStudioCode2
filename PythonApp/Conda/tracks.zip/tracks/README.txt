
There are two versions of the tracks application:

-  tracks_csv.py - Reads the tracks.csv file

-  tracks.py Reads and parses the Library.xml file which is exported from iTunes

The tracks_csv.py file is simpler and easier to understand and focuses on the
database learning objectives of this sample code.

If you are using the original tracks.py that is reading XML, you can 
export your own Library.xml from iTunes 

File -> Library -> Export Library

Make sure it is in the correct folder.   Of course iTunes might change
UI and/or export format any time - so good luck :)
